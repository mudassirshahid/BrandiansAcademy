
$("#write-content").summernote({
	enterHtml: '<p>&nbsp;</p>',
	minHeight: 250,             // set minimum height of editor
	focus: true,                  // set focus to editable area after initializing summernote
});

